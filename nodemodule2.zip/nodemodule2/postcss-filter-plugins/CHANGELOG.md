# 2.0.3

* Remove vulnerable downstream dependency

# 2.0.2

* Bumped uniqid to `4.0.0`.

# 2.0.1

* Bumped uniqid to `3.0.0` (thanks to @papandreou).

# 2.0.0

* Upgraded to PostCSS 5.

# 1.0.1

* Fixes an integration issue with cssnano & cssnext, caused by processors that
  do not expose a `postcssPlugin` property.

# 1.0.0

* Initial release.
