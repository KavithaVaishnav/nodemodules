<a name="1.2.0"></a>
# [1.2.0](https://github.com/michael-ciniawsky/postcss-load-config/compare/v1.1.0...v1.2.0) (2017-02-13)


### Features

* **index:** allow extensions for .postcssrc ([0d3bf35](https://github.com/michael-ciniawsky/postcss-load-config/commit/0d3bf35))



<a name="1.1.0"></a>
# [1.1.0](https://github.com/michael-ciniawsky/postcss-load-config/compare/v1.0.0...v1.1.0) (2017-01-11)


### Features

* **index:** config.file, improve error handling ([a6c32fd](https://github.com/michael-ciniawsky/postcss-load-config/commit/a6c32fd))



<a name="1.0.0"></a>
# [1.0.0]((https://github.com/michael-ciniawsky/postcss-load-config/compare/v1.0.0-rc...1.0.0)) (2016-10-27)


### Bug Fixes

* **index:** behavior when config loading fails ([b549bc6](https://github.com/michael-ciniawsky/postcss-load-config/commit/b549bc6)), closes [#26](https://github.com/michael-ciniawsky/postcss-load-config/issues/26)
* **index:** set NODE_ENV when undefined ([b24501c](https://github.com/michael-ciniawsky/postcss-load-config/commit/b24501c))
* **index:** support node v0.12 ([0bbfa94](https://github.com/michael-ciniawsky/postcss-load-config/commit/0bbfa94))

### Features

* **index:** function support, jsdoc, cleanups ([a78c580](https://github.com/michael-ciniawsky/postcss-load-config/commit/a78c580))
