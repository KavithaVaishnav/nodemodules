# 1.0.1

* Update the initial value of `user-select` from `none` to `auto`.

# 1.0.0

* Initial release.
