#!/usr/bin/env node
console.log(JSON.stringify(process.argv));
